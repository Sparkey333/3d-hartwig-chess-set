Neo Chess 1.1.0 — for THIS Mac
===================================

INSTALL (clear steps)
1. Open this DMG (double-click the .dmg in Downloads)
2. Drag "Neo Chess.app" into Applications
3. Eject the volume
4. Launch Applications → Neo Chess
   First open may need: right-click → Open (unsigned local build)

SETUP / API KEYS
Open "SETUP — Keys & Install.html" on this volume, or use the Setup tab in the app.

Higgsfield Cloud (primary AI keys):
  https://cloud.higgsfield.ai/
  https://docs.higgsfield.ai
  https://status.higgsfield.ai

OpenAI (optional fallback images):
  https://platform.openai.com/api-keys

Colorado / OTB:
  https://coloradochess.com/
  https://coloradochess.com/tournaments/view-upcoming/
  https://chesstournamentguide.com/events/state/co/
  https://new.uschess.org/
  https://new.uschess.org/msa/

Stack:
  https://stockfishchess.org/
  https://github.com/jhlywa/chess.js
  https://github.com/Clariity/react-chessboard
  https://github.com/higgsfield-ai/higgsfield-js

Local .env (for Premium live AI):
  HF_CREDENTIALS=KEY_ID:KEY_SECRET
  OPENAI_API_KEY=sk-...
  npm run dev

Rebuild package into Downloads:
  npm run pack:mac
  open ~/Downloads/Neo-Chess-1.1.0-mac.dmg
