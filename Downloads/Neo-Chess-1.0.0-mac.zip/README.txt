Neo Chess 1.0.0 for macOS
================================

Install:
1. Drag "Neo Chess.app" into Applications
2. Double-click Neo Chess to open the game
3. Or open "Open Landing Page.html" for the product site and download info

Colorado Springs clubs, competition variants, Neo modes, and Premium AI features included.

Website landing (local): Open Landing Page.html
